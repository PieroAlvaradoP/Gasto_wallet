package com.gastowallet.gasto_wallet;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
